const players = ["Ali", "Ayşe", "Mehmet"];
let currentPlayer = -1;
let lastPlayer = -1;
let scores = Array(players.length).fill(0);
let passes = Array(players.length).fill(3);
let round = 1;
let totalRounds = 5;

const truths = ["En büyük korkun nedir?", "Hiç yalan söyledin mi?", "Bir sırrını açıkla."];
const dares = ["Komik bir ses çıkar.", "Olduğun yerde dans et.", "Ters konuşmaya çalış."];

const wheel = document.getElementById("wheel");
const ctx = wheel.getContext("2d");
const spinBtn = document.getElementById("spinButton");
const truthBtn = document.getElementById("truthBtn");
const dareBtn = document.getElementById("dareBtn");
const passBtn = document.getElementById("passBtn");
const skipBtn = document.getElementById("skipBtn");
const restartBtn = document.getElementById("restartBtn");

function drawWheel() {
  const angle = (2 * Math.PI) / players.length;
  for (let i = 0; i < players.length; i++) {
    ctx.beginPath();
    ctx.fillStyle = i % 2 === 0 ? "#3498db" : "#e74c3c";
    ctx.moveTo(150, 150);
    ctx.arc(150, 150, 150, angle * i, angle * (i + 1));
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.save();
    ctx.translate(150, 150);
    ctx.rotate(angle * (i + 0.5));
    ctx.textAlign = "right";
    ctx.font = "16px Arial";
    ctx.fillText(players[i], 140, 10);
    ctx.restore();
  }
}

function getRandomPlayer() {
  let idx;
  do {
    idx = Math.floor(Math.random() * players.length);
  } while (idx === lastPlayer);
  lastPlayer = idx;
  return idx;
}

function updateScoreBoard() {
  const scoreBoard = document.getElementById("scoreBoard");
  scoreBoard.innerHTML = "<h3>Puanlar</h3>" + players.map((p, i) => `${p}: ${scores[i]} puan`).join("<br>");
}

function updateRoundInfo() {
  document.getElementById("roundInfo").innerText = `Tur: ${round} / ${totalRounds}`;
}

function endGame() {
  const max = Math.max(...scores);
  const min = Math.min(...scores);
  const winner = players[scores.indexOf(max)];
  const loser = players[scores.indexOf(min)];
  document.getElementById("resultBox").innerHTML = `
    <h2>Kazanan: ${winner}</h2>
    <p>🎉 Tebrikler! 🎉</p>
    <h3>Kaybeden: ${loser}</h3>
    <p>Ceza: 1 dakika boyunca tavuk gibi yürü! 🐔</p>
  `;
  restartBtn.classList.remove("hidden");
}

spinBtn.addEventListener("click", () => {
  if (round > totalRounds) return;
  currentPlayer = getRandomPlayer();
  document.getElementById("playerInfo").innerText = `Sıra: ${players[currentPlayer]}`;
  document.getElementById("choiceButtons").classList.remove("hidden");
  document.getElementById("actionButtons").classList.add("hidden");
  document.getElementById("questionBox").innerText = "";
  updateScoreBoard();
  updateRoundInfo();
});

truthBtn.addEventListener("click", () => {
  const q = truths[Math.floor(Math.random() * truths.length)];
  document.getElementById("questionBox").innerText = q;
  scores[currentPlayer] += 3;
  endTurn();
});

dareBtn.addEventListener("click", () => {
  const q = dares[Math.floor(Math.random() * dares.length)];
  document.getElementById("questionBox").innerText = q;
  scores[currentPlayer] += 5;
  endTurn();
});

passBtn.addEventListener("click", () => {
  if (passes[currentPlayer] > 0) {
    passes[currentPlayer]--;
    document.getElementById("questionBox").innerText = "Pas geçildi.";
    endTurn();
  } else {
    document.getElementById("questionBox").innerText = "Pas hakkın bitti!";
  }
});

skipBtn.addEventListener("click", () => {
  scores[currentPlayer] -= 1;
  document.getElementById("questionBox").innerText = "Görevden kaçtın!";
  endTurn();
});

restartBtn.addEventListener("click", () => {
  location.reload();
});

function endTurn() {
  round++;
  if (round > totalRounds) {
    endGame();
  }
  document.getElementById("choiceButtons").classList.add("hidden");
  document.getElementById("actionButtons").classList.remove("hidden");
  updateScoreBoard();
}

drawWheel();
updateScoreBoard();
updateRoundInfo();
